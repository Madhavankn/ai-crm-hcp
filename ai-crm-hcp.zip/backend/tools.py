def log_interaction(text):
    return {
        "hcp_name": "Dr. Sharma",
        "products": ["Insulin"],
        "summary": text,
        "follow_up": "Next Week"
    }

def edit_interaction(data, updates):
    data.update(updates)
    return data

def get_history(hcp_name):
    return [{"hcp_name": hcp_name, "summary": "Previous meeting"}]

def suggest_action(text):
    return "Schedule follow-up meeting"

def sentiment_analysis(text):
    return "Positive"
