from fastapi import FastAPI
from pydantic import BaseModel
from langgraph_agent import run_agent

app = FastAPI()

class ChatInput(BaseModel):
    message: str

@app.post("/chat")
async def chat(input: ChatInput):
    result = run_agent(input.message)
    return result
