from tools import log_interaction, sentiment_analysis, suggest_action

def run_agent(user_input):
    state = {}
    state["entities"] = log_interaction(user_input)
    state["sentiment"] = sentiment_analysis(user_input)
    state["suggestion"] = suggest_action(user_input)
    return state
