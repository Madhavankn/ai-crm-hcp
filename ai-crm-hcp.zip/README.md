# AI CRM HCP Module
Run backend and frontend as instructed.