import React, { useState } from "react";
import axios from "axios";

export default function ChatInterface() {
  const [message, setMessage] = useState("");
  const [response, setResponse] = useState(null);

  const sendMessage = async () => {
    const res = await axios.post("http://localhost:8000/chat", { message });
    setResponse(res.data);
  };

  return (
    <div>
      <input value={message} onChange={e => setMessage(e.target.value)} />
      <button onClick={sendMessage}>Send</button>
      {response && <pre>{JSON.stringify(response, null, 2)}</pre>}
    </div>
  );
}
