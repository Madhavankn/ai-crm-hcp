import React, { useState } from "react";
import StructuredForm from "./StructuredForm";
import ChatInterface from "./ChatInterface";

export default function LogInteractionScreen() {
  const [mode, setMode] = useState("chat");

  return (
    <div>
      <button onClick={() => setMode("form")}>Form</button>
      <button onClick={() => setMode("chat")}>Chat</button>
      {mode === "form" ? <StructuredForm /> : <ChatInterface />}
    </div>
  );
}
