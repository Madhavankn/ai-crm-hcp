import React, { useState } from "react";

export default function StructuredForm() {
  const [data, setData] = useState({});

  return (
    <div>
      <input placeholder="HCP Name" onChange={e => setData({...data, hcp_name: e.target.value})} />
      <textarea placeholder="Notes" onChange={e => setData({...data, notes: e.target.value})} />
      <button onClick={() => console.log(data)}>Submit</button>
    </div>
  );
}
