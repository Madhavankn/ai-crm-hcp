CREATE TABLE interactions (
    id SERIAL PRIMARY KEY,
    hcp_name VARCHAR(255),
    products JSON,
    summary TEXT,
    follow_up_date DATE,
    sentiment VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
